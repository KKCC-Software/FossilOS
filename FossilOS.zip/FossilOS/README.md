# FossilOS (minimal)

FossilOS — minimalist hobby OS kernel (C, 32-bit).  
This small starter project prints a welcome message to VGA text memory and halts.

## Build requirements (on Linux Mint / Ubuntu)
Install tools:
```bash
sudo apt update
sudo apt install build-essential nasm grub-pc-bin xorriso -y
